create definer = root@`%` view testview as
select `bru`.`id`       AS `id`,
       `bru`.`uuid`     AS `uuid`,
       `bru`.`url`      AS `url`,
       `bru`.`req_time` AS `req_time`,
       `bru`.`ip`       AS `ip`,
       `bru`.`deleted`  AS `deleted`,
       `bru`.`ctime`    AS `ctime`,
       `bru`.`crname`   AS `crname`,
       `bru`.`mtime`    AS `mtime`,
       `bru`.`chname`   AS `chname`
from `bill`.`bill_request_url` `bru`;

-- comment on column testview.id not supported: 主键id

-- comment on column testview.uuid not supported: uuid

-- comment on column testview.url not supported: 访问路径

-- comment on column testview.req_time not supported: 访问时间

-- comment on column testview.ip not supported: 访问ip

-- comment on column testview.deleted not supported: 删除标记

-- comment on column testview.ctime not supported: 创建时间

-- comment on column testview.crname not supported: 创建人

-- comment on column testview.mtime not supported: 更新时间

-- comment on column testview.chname not supported: 更新人

